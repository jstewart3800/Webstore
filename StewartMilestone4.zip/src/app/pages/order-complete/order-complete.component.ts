import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-order-complete',
  templateUrl: './order-complete.component.html',
  styleUrls: ['./order-complete.component.scss']
})
export class OrderCompleteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
