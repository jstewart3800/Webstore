export interface ProductInterface {
    id: number;
    name: string;
    category: string;
    desc: string;
    URL: string;
    price: number;
    img: string;
    qty: number;
}
